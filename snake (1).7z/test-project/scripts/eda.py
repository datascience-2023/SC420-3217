import pandas as pd
from ydata_profiling import ProfileReport

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--input", help="Input file path")
parser.add_argument("--output", help="Output file path")
args = parser.parse_args()

df = pd.read_csv(args.input)

profile = ProfileReport(df)

profile.to_file(output_file=args.output)
